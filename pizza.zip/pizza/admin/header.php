
<!DOCTYPE html>
<html>
<head>
	<title>The Pizza Box/Admin</title>

	<link rel="stylesheet" href="../css/pizza_style.css" type="text/css" media="screen" />


</head>



</head>
<body style="background-image: url(../images/body-bg.jpg);">
	<center>


<div style="width: 80%;"> 
  <ul class="above_menu">
    <li style="float: left;"><img src="../logo.png"></li>
    <li style="float: right;"><h1><a class="active"  href="../logout.php">Logout</a></h1></li>
  </ul>
</div>


<div style="width: 80%;">
  <ul class="menu">
    <li class="menu_link"><h1><a href="viewpizza.php">Pizza</a></h1></li>
    <li class="menu_link"><h1><a href="viewtopping.php">Topings</a></h1></li>
</div>   
  </ul>
</div>


</center>
</body>
</html>
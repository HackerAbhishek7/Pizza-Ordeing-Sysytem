<?php 
$conn=mysqli_connect("localhost","root","","pizza")or die("Can't Connect...");
	
?>
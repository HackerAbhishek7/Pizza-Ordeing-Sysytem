<!DOCTYPE html>
<html>
<head>
	<title>Pizzitalia</title>

	<link rel="stylesheet" href="css/pizza_style.css" type="text/css" media="screen" />

</head>
<body style="background-image: url(images/body-bg.jpg);">
	<center>


<div> 
  <ul class="above_menu" style="background-image: url(images/header-bg.png);">
    <li style="float: left;"><img src="logo.png"></li>

    <li style="float: right;"><h1><a class="active"  href="logout.php">Logout</a></h1></li>
    <li style="float: right;"><h1><a class="active"  href="logout.php">Register</a></h1></li>

  </ul>
</div>

</center>
</body>
</html>
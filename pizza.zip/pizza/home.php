<?php

	require("header.php");

?>
<!-- Start WOWSlider.com HEAD section -->
	<link rel="stylesheet" type="text/css" href="engine14//style.css" media="screen" />
	<script type="text/javascript" src="engine14//jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->


<!-- Start WOWSlider.com BODY section id=wowslider-container14-->
	<div id="wowslider-container14">
	<div class="ws_images"><ul>
<li><img src="data14/images/pizza_slider_4.jpg" alt="pizza_slider (4)" title="pizza_slider (2)" id="wows14_0"/></li>
<li><img src="data14/images/pizza_slider_3.jpg" alt="pizza_slider (3)" title="pizza_slider (3)" id="wows14_1"/></li>
<li><img src="data14/images/pizza_slider_2.jpg" alt="pizza_slider (2)" title="pizza_slider (4)" id="wows14_2"/></li>
<li><img src="data14/images/pizza_slider_1.jpg" alt="pizza_slider (1)" title="pizza_slider (1)" id="wows14_3"/></li>
</ul></div>
<div class="ws_bullets"><div>
<a href="#" title="pizza_slider (4)">1</a>
<a href="#" title="pizza_slider (3)">2</a>
<a href="#" title="pizza_slider (2)">3</a>
<a href="#" title="pizza_slider (1)">4</a>
</div></div>
	<a href="#" class="ws_frame"></a>
	<div class="ws_shadow"></div>
	</div>
	<script type="text/javascript" src="engine14//wowslider.js"></script>
	<script type="text/javascript" src="engine14//script.js"></script>
<!-- End WOWSlider.com BODY section -->

<?php require("footer.php"); ?>

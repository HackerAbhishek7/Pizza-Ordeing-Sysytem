<?php 
include('config.php');
require("header.php");
require("admin/connection.php");

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<br><br><br><br><br><br><br>
<!--
<script type="text/javascript">
	function print_recipt() {
		window.print();
	}
</script>
-->
</br>
<center><h1>You have successfully placed your order!!!</h1></center>
<br><br><br><br><br><br><br>
<center><h2>Thank's for placing order with us.</h2> </center>
</body>
</html>